targetScope = 'subscription'

import { DeploymentSettings } from './types.bicep'

@description('Deployment Setup values consumed by the static Bicep templates.')
param settings DeploymentSettings

var storageNetwork = settings.?DEPLOY_STORAGE_NETWORK ?? false

resource existingEnvironment 'Microsoft.App/managedEnvironments@2024-03-01' existing = if (settings.USE_EXISTING_ENVIRONMENT) {
  name: settings.ENVIRONMENT_NAME
  scope: resourceGroup(settings.ENVIRONMENT_RESOURCE_GROUP)
}

module network 'modules/network.bicep' = if (settings.PRIVATE_NETWORK_DEPLOYMENT || storageNetwork) {
  scope: resourceGroup(settings.NETWORK_RESOURCE_GROUP)
  params: {
    settings: settings
  }
}

module foundation 'modules/foundation.bicep' = {
  scope: resourceGroup(settings.CONTAINER_APP_RESOURCE_GROUP)
  params: {
    settings: settings
    acaSubnetId: network.?outputs.acaSubnetId ?? ''
    existingEnvironmentId: existingEnvironment.?id ?? ''
    existingEnvironmentDomain: existingEnvironment.?properties.defaultDomain ?? ''
    existingEnvironmentStaticIp: existingEnvironment.?properties.staticIp ?? ''
  }
}

module configuration 'modules/configuration.bicep' = {
  scope: resourceGroup(settings.APPCONFIG_RESOURCE_GROUP)
  params: {
    settings: settings
  }
}

module companionAppBootstrap 'modules/companion-app.bicep' = if (settings.DEPLOY_COMPANION_APP) {
  scope: resourceGroup(settings.COMPANION_APP_RESOURCE_GROUP)
  params: {
    settings: settings
    usePrivateRegistry: false
    environmentId: foundation.outputs.environmentId
    serverBaseUrl: 'https://${containerAppBootstrap.?outputs.proxyFqdn ?? ''}'
    appConfigurationEndpoint: ''
    appInsightsConnectionString: foundation.outputs.appInsightsConnectionString
    sidecarUrl: containerAppBootstrap.?outputs.healthProbeSidecarUrl ?? ''
    metricsServerUrl: metricsServerBootstrap.?outputs.url ?? ''
  }
}

module eventHub 'modules/event-hub.bicep' = if (settings.DEPLOY_COMPANION_APP) {
  scope: resourceGroup(settings.COMPANION_APP_RESOURCE_GROUP)
  params: {
    settings: settings
  }
}

module eventHubAccess 'modules/event-hub-access.bicep' = if (settings.DEPLOY_COMPANION_APP) {
  scope: resourceGroup(settings.COMPANION_APP_RESOURCE_GROUP)
  params: {
    settings: settings
    companionAppPrincipalId: companionAppBootstrap.?outputs.identityPrincipalId ?? ''
    proxyPrincipalId: containerAppBootstrap.?outputs.identityPrincipalId ?? ''
  }
  dependsOn: [
    eventHub
  ]
}

module metricsServerBootstrap 'modules/metrics-server.bicep' = if (settings.DEPLOY_METRICS_SERVER) {
  scope: resourceGroup(settings.CONTAINER_APP_RESOURCE_GROUP)
  params: {
    settings: settings
    usePrivateRegistry: false
    environmentId: foundation.outputs.environmentId
    appConfigurationEndpoint: ''
  }
}

module blobStorage 'modules/blob-storage.bicep' = if (settings.ASYNC_DEPLOYMENT || storageNetwork) {
  scope: resourceGroup(settings.STORAGE_RESOURCE_GROUP)
  params: {
    settings: settings
  }
}

module storagePrivateEndpoint 'modules/storage-private-endpoint.bicep' = if (storageNetwork) {
  scope: resourceGroup(settings.NETWORK_RESOURCE_GROUP)
  params: {
    settings: settings
    storageAccountId: blobStorage.?outputs.storageAccountId ?? ''
    privateEndpointSubnetId: network.?outputs.privateEndpointSubnetId ?? ''
    virtualNetworkId: network.?outputs.virtualNetworkId ?? ''
  }
}

module profiles 'modules/profiles.bicep' = if (storageNetwork) {
  scope: resourceGroup(settings.STORAGE_RESOURCE_GROUP)
  params: {
    location: settings.LOCATION
    storageAccountName: settings.STORAGE_ACCOUNT_NAME
    environmentId: foundation.outputs.environmentId
    appPrincipalIds: concat(
      settings.DEPLOY_PROXY ? [containerAppBootstrap.?outputs.identityPrincipalId ?? ''] : [],
      settings.DEPLOY_COMPANION_APP ? [companionAppBootstrap.?outputs.identityPrincipalId ?? ''] : []
    )
  }
  dependsOn: [
    storagePrivateEndpoint
  ]
}

module requestApi 'modules/request-api.bicep' = if (settings.ASYNC_DEPLOYMENT) {
  scope: resourceGroup(settings.REQUESTAPI_RESOURCE_GROUP)
  params: {
    settings: settings
    functionsSubnetId: network.?outputs.functionsSubnetId ?? ''
  }
  dependsOn: [
    foundation
  ]
}

module cosmosAccess 'modules/cosmos-access.bicep' = if (settings.ASYNC_DEPLOYMENT) {
  scope: resourceGroup(settings.COSMOS_RESOURCE_GROUP)
  params: {
    settings: settings
    requestIdentityId: requestApi.?outputs.identityId ?? ''
    requestIdentityPrincipalId: requestApi.?outputs.identityPrincipalId ?? ''
  }
}

module containerAppBootstrap 'modules/container-app.bicep' = if (settings.DEPLOY_PROXY) {
  scope: resourceGroup(settings.CONTAINER_APP_RESOURCE_GROUP)
  params: {
    settings: settings
    usePrivateRegistry: false
    environmentId: foundation.outputs.environmentId
    appInsightsConnectionString: foundation.outputs.appInsightsConnectionString
    appConfigurationEndpoint: ''
    blobEndpoint: blobStorage.?outputs.blobEndpoint ?? ''
    requestApiHostName: requestApi.?outputs.functionHostName ?? ''
  }
}

module registryAccess 'modules/registry-access.bicep' = {
  scope: resourceGroup(settings.CONTAINER_APP_RESOURCE_GROUP)
  params: {
    settings: settings
    containerAppId: containerAppBootstrap.?outputs.containerAppId ?? ''
    containerAppPrincipalId: containerAppBootstrap.?outputs.identityPrincipalId ?? ''
    companionAppId: companionAppBootstrap.?outputs.appId ?? ''
    companionAppPrincipalId: companionAppBootstrap.?outputs.identityPrincipalId ?? ''
    metricsServerId: metricsServerBootstrap.?outputs.appId ?? ''
    metricsServerPrincipalId: metricsServerBootstrap.?outputs.identityPrincipalId ?? ''
  }
}

module configurationAccess 'modules/configuration-access.bicep' = {
  scope: resourceGroup(settings.APPCONFIG_RESOURCE_GROUP)
  params: {
    settings: settings
    configurationStoreId: configuration.outputs.configurationStoreId
    containerAppId: containerAppBootstrap.?outputs.containerAppId ?? ''
    containerAppPrincipalId: containerAppBootstrap.?outputs.identityPrincipalId ?? ''
    companionAppId: companionAppBootstrap.?outputs.appId ?? ''
    companionAppPrincipalId: companionAppBootstrap.?outputs.identityPrincipalId ?? ''
    metricsServerId: metricsServerBootstrap.?outputs.appId ?? ''
    metricsServerPrincipalId: metricsServerBootstrap.?outputs.identityPrincipalId ?? ''
  }
}

module companionApp 'modules/companion-app.bicep' = if (settings.DEPLOY_COMPANION_APP) {
  scope: resourceGroup(settings.COMPANION_APP_RESOURCE_GROUP)
  params: {
    settings: settings
    usePrivateRegistry: true
    environmentId: foundation.outputs.environmentId
    serverBaseUrl: 'https://${containerAppBootstrap.?outputs.proxyFqdn ?? ''}'
    eventHubMonitorEnabled: true
    appConfigurationEndpoint: configuration.outputs.endpoint
    appInsightsConnectionString: foundation.outputs.appInsightsConnectionString
    sidecarUrl: containerAppBootstrap.?outputs.healthProbeSidecarUrl ?? ''
    metricsServerUrl: metricsServerBootstrap.?outputs.url ?? ''
  }
  dependsOn: [
    registryAccess
    configurationAccess
    eventHubAccess
    profiles
    blobAccess
  ]
}

module metricsServer 'modules/metrics-server.bicep' = if (settings.DEPLOY_METRICS_SERVER) {
  scope: resourceGroup(settings.CONTAINER_APP_RESOURCE_GROUP)
  params: {
    settings: settings
    usePrivateRegistry: true
    environmentId: foundation.outputs.environmentId
    appConfigurationEndpoint: configuration.outputs.endpoint
  }
  dependsOn: [
    registryAccess
    configurationAccess
  ]
}

module blobAccess 'modules/blob-access.bicep' = if (settings.ASYNC_DEPLOYMENT && (settings.DEPLOY_PROXY || settings.DEPLOY_COMPANION_APP)) {
  scope: resourceGroup(settings.STORAGE_RESOURCE_GROUP)
  params: {
    settings: settings
    containerAppId: containerAppBootstrap.?outputs.containerAppId ?? ''
    containerAppPrincipalId: containerAppBootstrap.?outputs.identityPrincipalId ?? ''
    companionAppPrincipalId: companionAppBootstrap.?outputs.identityPrincipalId ?? ''
  }
  dependsOn: [
    // Companion-only deployments skip the proxy bootstrap's dependency on storage.
    #disable-next-line no-unnecessary-dependson
    blobStorage
  ]
}

module serviceBusAccess 'modules/service-bus-access.bicep' = if (settings.ASYNC_DEPLOYMENT) {
  scope: resourceGroup(settings.SERVICEBUS_RESOURCE_GROUP)
  params: {
    settings: settings
    requestIdentityId: requestApi.?outputs.identityId ?? ''
    requestIdentityPrincipalId: requestApi.?outputs.identityPrincipalId ?? ''
    containerAppId: containerAppBootstrap.?outputs.containerAppId ?? ''
    containerAppPrincipalId: containerAppBootstrap.?outputs.identityPrincipalId ?? ''
  }
}

module containerApp 'modules/container-app.bicep' = if (settings.DEPLOY_PROXY) {
  scope: resourceGroup(settings.CONTAINER_APP_RESOURCE_GROUP)
  params: {
    settings: settings
    usePrivateRegistry: true
    environmentId: foundation.outputs.environmentId
    appInsightsConnectionString: foundation.outputs.appInsightsConnectionString
    appConfigurationEndpoint: configuration.outputs.endpoint
    blobEndpoint: blobStorage.?outputs.blobEndpoint ?? ''
    requestApiHostName: requestApi.?outputs.functionHostName ?? ''
  }
  dependsOn: [
    registryAccess
    configurationAccess
    blobAccess
    profiles
    serviceBusAccess
  ]
}

module privateDns 'modules/private-dns.bicep' = if (settings.PRIVATE_NETWORK_DEPLOYMENT && settings.DEPLOY_PROXY) {
  scope: resourceGroup(settings.NETWORK_RESOURCE_GROUP)
  params: {
    settings: settings
    environmentDomain: foundation.outputs.environmentDomain
    environmentStaticIp: foundation.outputs.environmentStaticIp
    proxyFqdn: containerApp.?outputs.proxyFqdn ?? ''
  }
}

output proxyUrl string = settings.DEPLOY_PROXY ? 'https://${containerApp.?outputs.proxyFqdn ?? ''}' : ''
output companionAppUrl string = companionApp.?outputs.url ?? ''
output metricsServerUrl string = metricsServer.?outputs.url ?? ''
output profileSeedJobName string = profiles.?outputs.jobName ?? ''
output profileSeedJobResourceGroup string = profiles.?outputs.jobResourceGroup ?? ''
